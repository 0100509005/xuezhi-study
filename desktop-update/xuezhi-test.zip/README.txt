Synthetic updater test. No application or study materials.
